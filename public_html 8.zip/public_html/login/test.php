<title>Login - Eclipse</title>
   <head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/cosmo/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<nav class="navbar navbar-custom">
  <a class="navbar-brand" href="#">why cant i see the links</a>
<div class="collapse navbar-collapse" id="navbarSupportedContent">
<ul class="navbar-nav mr-auto">
<li class="nav-item">
<a class="nav-link active" href="https://tadah.rocks/my/dashboard"><i class="fas fa-home mr-1"></i>Home</a>
</li>
<li class="nav-item">
<a class="nav-link " href="https://tadah.rocks/servers"><i class="fas fa-gamepad-alt mr-1"></i>Servers</a>
</li>
<li class="nav-item">
<a class="nav-link " href="https://tadah.rocks/catalog"><i class="fas fa-shopping-bag mr-1"></i>Catalog</a>
</li>
<li class="nav-item">
<a class="nav-link " href="https://tadah.rocks/users"><i class="fas fa-users mr-1"></i>Users</a>
</li>
<li class="nav-item">
<a class="nav-link " href="https://tadah.rocks/forum"><i class="fas fa-comments-alt mr-1"></i>Forums</a>
</li>
</ul>
<ul class="navbar-nav ml-auto">
<li class="nav-item">
<span id="reward" class="navbar-text" data-toggle="tooltip" data-placement="bottom" data-original-title="1 minute, 19 seconds until your next reward" data-tadah-started="1646567089">
<img style="filter: opacity(75%);" src="/images/dahllor_white.png" alt="20 Tokens" width="16" height="20"> 20
</span>
</li>
<li class="nav-item ml-1 dropdown">
<a id="navbarropdown" class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre="">
<img src="https://cdn.tadah.rocks/35836fee89f17078615f58aa41f12b24462699356ac744ed96f2ebcc91b49f55" data-tadah-thumbnail-id="585" data-tadah-thumbnail-type="user-headshot" class="rounded-circle mr-1 shadow-sm" width="25" id="navigation-headshot" style="">
xyxs
<i class="fas fa-cog ml-1 align-middle"></i>
</a>
<div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
<a class="dropdown-item" href="https://tadah.rocks/users/585/profile">
<i class="fas fa-id-card mr-1 align-middle"></i>Profile
</a>
<a class="dropdown-item" href="/character">
<i class="fas fa-fw fa-user-edit mr-1 align-middle"></i>Character
</a>
<a class="dropdown-item" href="https://tadah.rocks/my/settings">
<i class="fas fa-fw fa-cog mr-1 align-middle"></i>Settings
</a>
<div class="dropdown-divider"></div>
<a class="dropdown-item text-danger font-weight-bold" href="https://tadah.rocks/logout" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
<i class="fas fa-fw fa-sign-out-alt mr-1 align-middle"></i>Logout
</a>
<form id="logout-form" action="https://tadah.rocks/logout" method="POST" class="d-none">
<input type="hidden" name="_token" value="7lVKTe8iYQtHPjR4WTQ4Q16G2P7pMFmcLNklsb9j"> </form>
</div>
</li>
</ul>
</div>
 </div>
</nav>
<style>
        /* Modify the background color */
         
        .navbar-custom {
            background-color: #5F04B4;
        }
        /* Modify brand and text color */
         
        .navbar-custom .nav-item,
        .navbar-custom .nav-link,
        .navbar-custom .navbar-brand,
        .navbar-custom .navbar-text {
            color: white;
        }
    </style>
  <div class="navbar-scroller navbar-expand-md navbar-dark navbar-second bg-dark py-0 shadow-sm" id="nav-items">
<div class="container">
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#secondary-navbar" aria-controls="secondary-navbar" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="secondary-navbar">
<ul class="navbar-nav">
<li class="nav-item" data-route="../home.php">
<a class="nav-link" href="../home.php">Home</a>
</li>
<li class="nav-item" data-route="../games.php">
<a class="nav-link" href="../games">Games</a>
</li>
<li class="nav-item" data-route="../users.php">
<a class="nav-link" href="../users">Users</a>
</li>
<li class="nav-item" data-route="/account.php">
<a class="nav-link" href="../account">Account</a>
</li>
</ul>
</div>
</div>
</div>