
   <?php include 'header.php'?>
      <h1>Hello, <?php echo htmlspecialchars($_SESSION["username"]); ?></h1>
    <br>
    <div class="StandardBox"  style = "overflow:hidden;margin: 0px 0px 5px 0px; border: 1px solid #9e9e9e; background: white;width:198px;">
                <center>
                    
                    <a id="ctl00_ctl00_cphRoblox_cphMyRobloxContent_AvatarImage" disabled="disabled" title="The funny" onclick="return false" style="display:inline-block;height:200px;width:200px;"><img src="/av.png" height="200" width="200" border="0" onerror="return Roblox.Controls.Image.OnError(this)" alt="<?php echo htmlspecialchars($_SESSION["username"]); ?>"/></a>
                </center>
                
                    
                 <!-- Top banner alerts moved down here -->
                <div style="width: inherit; margin: 0px 0px 0px 0px;">
                    <br clear="all" />
                    <br class="rbx2hide" />
                    
                    
                             
                    <div style="margin: 0px 0px 0px 0px;width: 188px; background-color: white; padding: 5px">
                        <center>
                            <b><a style="color: #5470bd;" href="/my/notifications.aspx">
                                0
                                System Notifications</a></b></center>
                    </div>
                </div>
            </div>

            <div id="ctl00_ctl00_cphRoblox_cphMyRobloxContent_pnlBestFriends">
  <h1>News</h1>
              <hr>
               <h2>Eclipse has been shut down.</h2><br>This project is no longer in development, and this website is being kept for archival purposes.
              <hr>
                   <button type="button" onclick="document.location='logout'" class="btn btn-danger">logout ›</button>
                    
                            <table width="inherit">
                        
                            
                        
                            </table><div style="clear:both;"></div>
                    
                    <div style="clear:both;"></div>
                </div>
                <div style="clear:both;"></div>
            
</div>
        </div>
  
  <div class="footer container">
      <hr>
      <p><b>Eclipse 2022</b> | Not affiliated with ROBLOX.</p>
    </div>