<?php
    $conn = mysqli_connect("mysql.ct8.pl", "m26459_users", "K7(5hxP5A$2F#qu@wiyC","m26459_users");
    if ($conn-> connect_error) {
      die("Connection failed:". $conn-> connect_error);
    }
// Initialize the session
session_start();
  
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: ../index.php");
    exit;
}
$sql = "SELECT id, username, blurb, cubes FROM users WHERE id = " . $_GET["user"] . "";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  echo " ";
  // output data of each row
  while($row = $result->fetch_assoc()) {
?>


    <title>User - Eclipse</title>
   <head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/cosmo/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
     <script src="https://kit.fontawesome.com/990114dcbd.js" crossorigin="anonymous"></script>
     <link rel="icon" href="../fav.png" type="image/x-icon"/>
</head>
<?php
// Initialize the session
session_start();
  
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: ../index.php");
    exit;
}
?>
<body>
    <nav class="navbar navbar-custom">
        <a class="navbar-brand" href="/">
          <div class="container">
         Eclipse
      </a>
    <ul class="navbar-nav ml-auto">
<li class="nav-item">

<li class="nav-item ml-1 dropdown">
<li class="nav-item">

<span id="reward" class="navbar-text" data-toggle="tooltip" data-placement="bottom" data-original-title="50 Cubes" data-started="1646567089">
<img style="filter: opacity(100%);" src="/cube-solid.png" alt="50 Cubes" width="18.5" height="20">&nbsp <b>50</b>
</span>
</li>
 
</div>
</li>
</ul>
</div>
 </div>
</nav>
      </nav>
               

    
    <script>
      $(function () {
        $('[data-toggle="tooltip"]').tooltip()
      });
    </script>

      
<style>
        /* Modify the background color */
         
        .navbar-custom {
            background-color: #5F04B4;
        }
        /* Modify brand and text color */
         
        .navbar-custom .navbar-brand,
        .navbar-custom .navbar-text {
            color: white;
        }
    </style>
    <style>
      .btn-primary, .btn-primary:hover, .btn-primary:active, .btn-primary:visited {
    background-color: #5F04B4 !important;
}
      </style>
<div class="navbar-scroller navbar-expand-md navbar-dark navbar-second bg-dark py-0 shadow-sm" id="nav-items">
<div class="container">
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#secondary-navbar" aria-controls="secondary-navbar" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="secondary-navbar">
<ul class="navbar-nav">
<li class="nav-item" data-route="../home.php">
<a class="nav-link" href="http://x.rccservice.xyz/home.php"><i class="fa-solid fa-house"></i>  Home</a>
</li>
<li class="nav-item" data-route="../games.php">
<a class="nav-link" href="http://x.rccservice.xyz/games"><i class="fa-solid fa-gamepad"></i>  Games</a>
</li>
<li class="nav-item" data-route="../users.php">
<a class="nav-link" href="http://x.rccservice.xyz/users"><i class="fa-solid fa-user-group"></i>  Users</a>
</li>
<li class="nav-item" data-route="/account.php">
<a class="nav-link" href="http://x.rccservice.xyz/account"><i class="fa-solid fa-gear"></i>  Settings</a>
  </li>
</ul>
</div>
</div>
</div>
    <br>
  <div class="container">       
    <h2><?php echo ''. $row["username"] .'';?>'s Profile</h2>
   

      
  
                
              
              
              <p class="text-success">Online</p>
    
              
                
            </div>
        </div>
        <div>
            <div>
                
                    <div style="margin-bottom: 10px;">
                        <span style="font-size: 13px;">
                     <div class="container">      
                        
                    
                    <a id="ctl00_cphRoblox_rbxUserPane_AvatarImage" disabled="disabled" title="USER_AVATAR" onclick="return false" style="display:inline-block;height:200px;width:200px;"><img src="http://x.rccservice.xyz/av.png" height="200" width="200" border="0" onerror="return Roblox.Controls.Image.OnError(this)" alt="<?php echo htmlspecialchars(_SESSION["username"]); ?>" blankurl="http://t4ak.roblox.com/p1-blank-150x200.gif"></a>
                    <br>
                    
                    

<div class="UserBlurb" style="margin-top: 10px; overflow-y: auto; max-height: 450px; ">
   <?php echo ''. $row["blurb"] .'';?>
</div>
<hr>
      
        <button type="button" class="btn btn-outline-secondary">Add Friend</button>
    
    <button type="button" class="btn btn-outline-secondary">Send Message</button>
    
    <div class="clear"></div>
    <script type="text/javascript">
        function hideDropdowns() {
            $('.GrayDropdown .Button.Active').removeClass('Active').siblings('.Menu').hide();
        }

        $('#ProfileButtons').width($('#FriendButton').outerWidth() + $('#MessageButton').outerWidth() + $('#MoreButton').outerWidth() + 10);
        $('.GrayDropdown .Button').click(function () {
            var show = !$(this).hasClass('Active');
            hideDropdowns();
            if (show) {
                $(this).addClass('Active').siblings('.Menu').show();
            }

            return false;
        });
        $(document).click(function () {
            hideDropdowns();
        });
    </script>
</div>

                    <div class="ProfileAlertPanel" style="display: none; margin: 15px auto 0px auto; width: 205px;">
                        
                        <br>
                    </div>
                    
                    
                </center>
            </div>
        </div>
    </div>
</div>

        

    
<?php
  }
  echo "</table>";
} else {
  echo "No users found with this ID.";
}
?>
          
          