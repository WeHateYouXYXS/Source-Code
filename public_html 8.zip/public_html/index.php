
    <title>Eclipse</title>
   <head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/cosmo/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
    <nav class="navbar navbar-custom">
        <a class="navbar-brand" href="/">
          <div class="container">
         Eclipse
      </a>
    </nav>
            
            
  
  <div class="container">
<div class="jumbotron text-center">
      <img src="/ec.png" class="img-responsive" style="margin: 0 auto; max-width: 300px; max-height: 200px;" alt="Eclipse">
    <br>
  <br>
  <p>We do what Carbon couldn't.</p>
  <br>
  <button type="button" onclick="document.location='register'" class="btn btn-primary">get started ›</button>
</div>
        

<div class="container">
  <div class="row">
    <div class="col-md-4 center well well-lg">
      <h4>95.5% more malware</h4>
      <p>we delete malwarebytes</p>
    </div>
    <div class="col-md-4 center well-lg">
      <h4>96.5% more malware</h4>
      <p>we delete malwarebytes</p>
    </div>
    <div class="col-md-4 center well well-lg">
      <h4>97.5% more malware</h4>
      <p>we still delete malwarebytes</p>
    </div>
  </div>
</div>

    <div class="footer container">
      <hr>
      <p><b>Eclipse 2022</b> | Not affiliated with ROBLOX.</p> 
    </div>

    
    <script>
      $(function () {
        $('[data-toggle="tooltip"]').tooltip()
      });
    </script>

      
<style>
        /* Modify the background color */
         
        .navbar-custom {
            background-color: #5F04B4;
        }
        /* Modify brand and text color */
         
        .navbar-custom .navbar-brand,
        .navbar-custom .navbar-text {
            color: white;
        }
    </style>
    <style>
      .btn-primary, .btn-primary:hover, .btn-primary:active, .btn-primary:visited {
    background-color: #5F04B4 !important;
}
      </style>
