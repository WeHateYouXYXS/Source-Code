hello welcome to download center
no css because the downloader will shit itself
<a href="client.zip">download here</a>