<?php include '../header.php'?>
    <br>
  <div class="container">
      <h1>Catalog</h1>
 <br>
    <div style="width: 20rem;" class="card">
      <br>
      <center>
        <br>
       <img src="https://cdn.discordapp.com/attachments/929701685989888000/950097110756393071/latest.png" alt="asset" width="200">
      </center>

        &nbsp;
        <h4> &nbsp&nbspNatural friendly monkey </h4>
        <h6> &nbsp&nbsp&nbspBy noitseuq </h6>
     <p class="text-success">&nbsp&nbsp&nbspfree</p>
      <br>
         <button type="button" onclick="document.location='#'" class="btn btn-primary">buy</button>

    </div>
</div>
        </div>

  <div class="footer container">
      <hr>
      <p><b>Eclipse 2022</b> | Not affiliated with ROBLOX.</p>
    </div>