<?php include '../header.php'?>
      <h1>Avatar</h1>
   <br>
    <img src="http://x.rccservice.xyz/av.png" alt="char" width="200" id="render">
    <br>
    <script language="javascript">
    function changeImage() {

        if (document.getElementById("render").src == "https://cdn.discordapp.com/attachments/929701685989888000/950097954302222416/funny.png") 
        {
    }
</script>
     <button type="button" onclick="changeImage()" class="btn btn-primary">re-render</button>
     <br>
    <br>
    <h4> Your items </h4>
    <br>
    <div style="width: 20rem;" class="card">
      <br>
      <center>
        <br>
       <img src="https://cdn.discordapp.com/attachments/929701685989888000/950097110756393071/latest.png" alt="asset" width="200">
      </center>
      
        &nbsp;
        <h4> &nbsp&nbspNatural friendly monkey </h4>
        <h6> &nbsp&nbsp&nbspBy noitseuq </h6>
      <br>
         <button type="button" onclick="change()" class="btn btn-primary" id="equip">equip</button>
          <script>
          function change() // no ';' here
{
    var elem = document.getElementById("equip");
    if (elem.value=="unequip") elem.value = "equip";
    else elem.value = "equip";
}
        </script>
    </div>
</div>
        </div>
  
  <div class="footer container">
      <hr>
      <p><b>Eclipse 2022</b> | Not affiliated with ROBLOX.</p>
    </div>













