
    <title>Eclipse</title>
   <head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/cosmo/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
     <script src="https://kit.fontawesome.com/990114dcbd.js" crossorigin="anonymous"></script>
     <link rel="icon" href="../fav.png" type="image/x-icon"/>
</head>
<?php
// Initialize the session
session_start();
  
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: ../index.php");
    exit;
}
?>
<body>
    <nav class="navbar navbar-custom">
        <a class="navbar-brand" href="/">
          <div class="container">
         Eclipse
      </a>
    <ul class="navbar-nav ml-auto">
<li class="nav-item">

<li class="nav-item ml-1 dropdown">
<li class="nav-item">

<span id="reward" class="navbar-text" data-toggle="tooltip" data-placement="bottom" data-original-title="50 Cubes" data-started="1646567089">
<img style="filter: opacity(100%);" src="/cube-solid.png" alt="50 Cubes" width="18.5" height="20">&nbsp <b>50</b>
</span>
</li>
 
</div>
</li>
</ul>
</div>
 </div>
</nav>
      </nav>
               

    
    <script>
      $(function () {
        $('[data-toggle="tooltip"]').tooltip()
      });
    </script>

      
<style>
        /* Modify the background color */
         
        .navbar-custom {
            background-color: #5F04B4;
        }
        /* Modify brand and text color */
         
        .navbar-custom .navbar-brand,
        .navbar-custom .navbar-text {
            color: white;
        }
    </style>
    <style>
      .btn-primary, .btn-primary:hover, .btn-primary:active, .btn-primary:visited {
    background-color: #5F04B4 !important;
}
      </style>
<div class="navbar-scroller navbar-expand-md navbar-dark navbar-second bg-dark py-0 shadow-sm" id="nav-items">
<div class="container">
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#secondary-navbar" aria-controls="secondary-navbar" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="secondary-navbar">
<ul class="navbar-nav">
<li class="nav-item" data-route="../home.php">
<a class="nav-link" href="http://x.rccservice.xyz/home.php"><i class="fa-solid fa-house"></i>  Home</a>
</li>
<li class="nav-item" data-route="../games.php">
<a class="nav-link" href="http://x.rccservice.xyz/games"><i class="fa-solid fa-gamepad"></i>  Games</a>
</li>
   <li class="nav-item" data-route="../catalog.php">
<a class="nav-link" href="http://x.rccservice.xyz/catalog"><i class="fa-solid fa-cart-shopping"></i>  Catalog</a>
</li>
<li class="nav-item" data-route="../users.php">
<a class="nav-link" href="http://x.rccservice.xyz/users"><i class="fa-solid fa-user-group"></i>  Users</a>
</li>
<li class="nav-item" data-route="/account.php">
<a class="nav-link" href="http://x.rccservice.xyz/account"><i class="fa-solid fa-gear"></i>  Settings</a></li>
  <div class="right">
    <li class="nav-item" data-route="/avatar.php">
<a class="nav-link" href="http://x.rccservice.xyz/avatar"><i class="fa-solid fa-user-astronaut"></i>  Character</a></li>
    </div>
</ul>
</div>
</div>
</div>
    <br>
  <div class="container">       