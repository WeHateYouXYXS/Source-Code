<?php include '../header.php'?>
<?php
    $conn = mysqli_connect("mysql.ct8.pl", "m26459_users", "K7(5hxP5A$2F#qu@wiyC","m26459_users");
    if ($conn-> connect_error) {
      die("Connection failed:". $conn-> connect_error);
    }
// Initialize the session
session_start();
 
// poop
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: index.php");
    exit;
}
?>

         <h2>My Account</h2>
<hr>
<h3>Username: <?php echo htmlspecialchars($_SESSION["username"]); ?></h3>
<h3>Description: <a><?php echo htmlspecialchars($_SESSION["blurb"]); ?></a> <a href="../description"><b>Edit</b></a></h3>
<h3>ID: <?php echo htmlspecialchars($_SESSION["id"]); ?></h3>
<h3>Join Date: <?php echo htmlspecialchars($_SESSION["created_at"]); ?></h3>
<h3>Cubes: <?php echo htmlspecialchars($_SESSION["cubes"]); ?>50</h3>
