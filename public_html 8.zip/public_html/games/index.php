
   <?php include '../header.php'?>
      <h1>Games</h1>
   <br>
    <div style="width: 20rem;" class="card">
      <br>
      <center>
       <img src="http://x.rccservice.xyz/img/place/nds.png" alt="Game icon" width="300">
      </center>
      
        &nbsp;
        <h4> &nbsp&nbspNatural Disaster Survival </h4>
        <h6> &nbsp&nbsp&nbspBy Eclipse </h6>
       <p class="text-danger">&nbsp&nbsp&nbsp0 playing</p>
      <br>
         <button type="button" onclick="document.location='/games/1/'" class="btn btn-primary">view</button>
          <button type="button" onclick="document.location='https://www.youtube.com/watch?v=iik25wqIuFo'" class="btn btn-success">download 2014</button>
        
    </div>
</div>
        </div>
  
  <div class="footer container">
      <hr>
      <p><b>Eclipse 2022</b> | Not affiliated with ROBLOX.</p>
    </div>







































